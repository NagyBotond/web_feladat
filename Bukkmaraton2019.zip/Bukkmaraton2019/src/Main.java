import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Main {

        //Nagy Botond

        public static void main(String[] args) {
            // 3. FELADATT
            Versenytav[] versenytavak = new Versenytav[1000];
            try {
                File file = new File("src/bukkm2019.txt");
                Scanner sc = new Scanner(file);
                sc.nextLine();
                int i = 0;
                while (sc.hasNextLine()) {
                    String line = sc.nextLine();
                    String[] parts = line.split(";");
                    String rajtszam = parts[0];
                    String kategoria = parts[1];
                    String nev = parts[2];
                    String egyesulet = parts[3];
                    String ido = parts[4];
                    versenytavak[i] = new Versenytav(rajtszam, kategoria, nev, egyesulet, ido);
                    i++;
                }
                sc.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            // 4. FELADATT
            System.out.println(((691 - versenytavak.length) / 691) * 100 + "% aránya a nem indultaknak ....");
        }
}
